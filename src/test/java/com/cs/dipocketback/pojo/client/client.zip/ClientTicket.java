package com.cs.dipocketback.pojo.client;

public class ClientTicket {
    
    private Integer ticketTypeId;
    
    public ClientTicket() {
    }

    public void setTicketTypeId(Integer ticketTypeId) {
        this.ticketTypeId = ticketTypeId;
    }

    public Integer getTicketTypeId() {
        return ticketTypeId;
    }
}
