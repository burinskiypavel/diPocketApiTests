package com.cs.dipocketback.pojo.client;

public class MainPhoneAndPin {
    
    private String mainPhone;
    private String pin1;
    private String pin2;
    private String code;
    
    public MainPhoneAndPin() {
    }

    public void setMainPhone(String mainPhone) {
        this.mainPhone = mainPhone;
    }

    public String getMainPhone() {
        return mainPhone;
    }

    public void setPin1(String pin1) {
        this.pin1 = pin1;
    }

    public String getPin1() {
        return pin1;
    }

    public void setPin2(String pin2) {
        this.pin2 = pin2;
    }

    public String getPin2() {
        return pin2;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
