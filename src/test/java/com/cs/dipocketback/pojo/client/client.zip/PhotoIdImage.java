package com.cs.dipocketback.pojo.client;

public class PhotoIdImage {
    
    private String value;
    private String valueBack;
    
    public PhotoIdImage() {
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setValueBack(String valueBack) {
        this.valueBack = valueBack;
    }

    public String getValueBack() {
        return valueBack;
    }
}
